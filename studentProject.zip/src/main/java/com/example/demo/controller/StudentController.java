package com.example.demo.controller;

import com.example.demo.exception.NotFoundException;
import com.example.demo.model.request.StudentDetailsRequestModel;
import com.example.demo.model.response.StudentResponseModel;
import com.example.demo.service.StudentService;
import com.example.demo.shared.dto.StudentDto;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "student")
@CrossOrigin(origins = "http://localhost:3000")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping
    public List<StudentResponseModel> getStudents() {
        List<StudentDto> studentDtos = studentService.getStudents();
        ArrayList<StudentResponseModel> responseList = new ArrayList<>();
        for (StudentDto studentDto : studentDtos) {
            StudentResponseModel response= new StudentResponseModel();
            BeanUtils.copyProperties(studentDto, response);
            responseList.add(response);
        }
        return responseList;
    }

    @GetMapping(value ="/{studentId}")
    public StudentResponseModel getStudent(@PathVariable String studentId){
        StudentResponseModel responseModel = new StudentResponseModel();
        Optional<StudentDto> optionalStudentDto = studentService.getStudentById(studentId);
        if(optionalStudentDto.isPresent()) {
            StudentDto studentDto = optionalStudentDto.get();
            BeanUtils.copyProperties(studentDto, responseModel);//this will copy this 2 values the rest is null
            return responseModel;
        }
        throw new NotFoundException("no id" + studentId);
    }

    //createStudent method that take in request tex from postman
    @PostMapping
    public ResponseEntity<StudentResponseModel> createStudent(@RequestBody StudentDetailsRequestModel studentDetailsModel){
        //Copy json to dto in
        StudentDto studentDtoIn = new StudentDto();
        //this will copy this 2 values the rest is null (detail is the json info)
        BeanUtils.copyProperties(studentDetailsModel, studentDtoIn);
        //pass dto in to service layer
        StudentDto studentDtoOut = studentService.createStudent(studentDtoIn);
        //copy dto out from service layer to response
        StudentResponseModel response = new StudentResponseModel();
        BeanUtils.copyProperties(studentDtoOut, response);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PutMapping("/{studentId}")
    public StudentResponseModel updateStudent(@PathVariable String studentId, @RequestBody StudentDetailsRequestModel requestData){
       StudentDto studentDtoIn = new StudentDto();
       BeanUtils.copyProperties(requestData, studentDtoIn);
       Optional<StudentDto> studentDtoOut = studentService.updateStudent(studentId, studentDtoIn);
       if(studentDtoOut.isEmpty()){
           throw new NotFoundException("No found");
       }
       StudentDto studentDto = studentDtoOut.get();
       StudentResponseModel responseModel = new StudentResponseModel();
       BeanUtils.copyProperties(studentDto, responseModel);
       return responseModel;
    }

    @DeleteMapping("/{studentId}")
    public String deleteStudent(@PathVariable String studentId) {
        boolean deleted = studentService.deleteStudent(studentId);
        if(deleted){
            return "Deleted student";
        }
        throw new NotFoundException(" Not this id" + studentId);
    }
}
