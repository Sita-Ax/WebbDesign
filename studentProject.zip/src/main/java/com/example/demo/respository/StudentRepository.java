package com.example.demo.respository;

import com.example.demo.respository.entity.StudentEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface StudentRepository extends CrudRepository<StudentEntity, Long> {

    Optional<StudentEntity> findByStudentId(String studentId);
    Long deleteByStudentId(String studentId);
    Optional<StudentEntity> findByEmail(String email);
}
