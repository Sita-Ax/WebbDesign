package com.example.demo.service;

import com.example.demo.shared.dto.StudentDto;
import java.util.List;
import java.util.Optional;

//the interface
public interface StudentService {

    StudentDto createStudent(StudentDto studentDetails);
    Optional<StudentDto> updateStudent(String studentId, StudentDto studentDtoIn);
    Optional<StudentDto> getStudentById(String studentId);
    boolean deleteStudent(String studentId);
    void deleteStudent(long id);
    List<StudentDto> getStudents();
}
