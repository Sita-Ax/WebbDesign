package com.example.demo.service.Imp;

import com.example.demo.exception.BadRequestException;
import com.example.demo.respository.StudentRepository;
import com.example.demo.respository.entity.StudentEntity;
import com.example.demo.service.StudentService;
import com.example.demo.shared.Util;
import com.example.demo.shared.dto.StudentDto;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;
    private final Util util;

    public StudentServiceImpl(StudentRepository studentRepository, Util util) {
        this.studentRepository = studentRepository;
        this.util = util;
    }

    public Optional<StudentDto> getStudentById(String studentId){
        Optional<StudentEntity> studentIdEntity = studentRepository.findByStudentId(studentId);
        return studentIdEntity.map(studentEntity -> {
            StudentDto studentDto = new StudentDto();
            BeanUtils.copyProperties(studentEntity, studentDto);
            return studentDto;
        });
    }

    public StudentDto createStudent(StudentDto studentDetailsIn){
        if(studentDetailsIn.getFirstName().equals("") ||
                studentDetailsIn.getLastName().equals("") ||
                studentDetailsIn.getEmail().equals("") ||
                studentDetailsIn.getPassword().equals("") ||
                studentDetailsIn.getAge() == 0
        ){
            throw new BadRequestException("its just null");
        }
        Optional<StudentEntity> checkEmailEntity = studentRepository.findByEmail(studentDetailsIn.getEmail());
        if(checkEmailEntity.isPresent()){
            throw new BadRequestException("user is already exist");
        }

        StudentEntity studentEntity = new StudentEntity();//src
        BeanUtils.copyProperties(studentDetailsIn, studentEntity);//this is just the four parameters

        String studentId = util.generateHash(studentDetailsIn.getEmail());
        studentEntity.setStudentId(studentId.substring(3));

        StudentEntity studentEntityOut = studentRepository.save(studentEntity);//this saved the entity copy ade return
        StudentDto studentDtoOut = new StudentDto();//just small details
        BeanUtils.copyProperties(studentEntityOut, studentDtoOut);//popylera
        return studentDtoOut;
}


    public Optional<StudentDto> updateStudent(String id, StudentDto studentDto){
        Optional<StudentEntity> studentIdEntity = studentRepository.findByStudentId(id);
        if(studentIdEntity.isEmpty())
            return Optional.empty();
        return studentIdEntity.map(studentEntity -> {
            StudentDto response = new StudentDto();
            studentEntity.setStudentId(studentDto.getStudentId() != null ? util.generateHash(studentDto.getStudentId()).substring(3) : studentEntity.getStudentId());
            studentEntity.setFirstName(studentDto.getFirstName() != null ? studentDto.getFirstName() : studentEntity.getFirstName());
            studentEntity.setLastName(studentDto.getLastName() != null ? studentDto.getLastName() : studentEntity.getLastName());
            studentEntity.setAge(studentDto.getAge() != 0 ? studentDto.getAge() : studentEntity.getAge());
            studentEntity.setEmail(studentDto.getEmail() != null ? studentDto.getEmail() : studentEntity.getEmail());
            studentEntity.setPassword(studentDto.getPassword() != null ? studentDto.getPassword() : studentEntity.getPassword());
            studentEntity.setPresent(studentDto.isPresent() != false ? studentDto.isPresent() : studentEntity.isPresent());
            StudentEntity updateStudentEntity = studentRepository.save(studentEntity);
            BeanUtils.copyProperties(updateStudentEntity, response);
            return response;
        });
    }

    //this give us count that i have deleted
    @Transactional
    public boolean deleteStudent(String id) {
        long removedCount = studentRepository.deleteByStudentId(id);
        return removedCount > 0;
    }

    @Override
    public void deleteStudent(long id) {
    studentRepository.deleteById(id);
    }


    //this give us the hole List
    public List<StudentDto> getStudents() {
        Iterable<StudentEntity> studentEntities = studentRepository.findAll();
        ArrayList<StudentDto> studentDtos = new ArrayList<>();
        for (StudentEntity studentEntity : studentEntities) {
            StudentDto studentDto = new StudentDto();
            BeanUtils.copyProperties(studentEntity, studentDto);
            studentDtos.add(studentDto);
        }
        return studentDtos;
    }
}
