import React, { useEffect, useState } from 'react';
import './style.css';

const Header = (props) => {
  const students = props.students
  return (
    <ul>
      {students.map((students, index) => {
        return (
          <li key={index}>
            <p className='fname'>{students.firstName}</p>
            <p className='lname'>{students.lastName}</p>
            <p className='age'>{students.age}</p>
            <p className='email'>{students.email}</p>
            <label>Present: </label>
            <input type='checkbox' id='present' name='student' value='studentId' checked={students.present} readOnly ></input>
            <button type= 'submit' onClick={() => { props.setView('Students'); }} >See students</button>
          </li>
        )
      })
      }
    </ul >
  )
}
    
const Students = (props) => {
  const students = props.students
  return (
    <ul>
      {students.map((students, index) => {
        return (
          <li key={index}>
            <p>{students.firstName} {students.lastName}
              <button className='btn' onClick={() => props.deleteStudent(students)}>Delete</button>
              <button className='btn' onClick={() => { props.setViewData(students.studentId); props.setView('UpdateStudent')}}>Update</button></p>
            <p className='email'>{students.email}</p>
            <p className='fname'>{students.firstName}</p>
            <p className='lname'>{students.lastName}</p>
            <p className='age'>{students.age}</p>
            <label>Present</label>
            <input type='checkbox' id='isPresent' name='student' value='studentId' checked={students.present} readOnly></input>
          </li>
        )
      })
      }
    </ul >
  )
}

const CreateStudent = (props) => {
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [age, setAge] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [present, setPresent] = useState(false)
  const onChangehandlerPresent = (e) =>{
    setPresent(prevpresent => !prevpresent)
  }
  const submitHandler = (e) => {
    e.preventDefault();
      const fetchStudents = async () => {
      const resp = await fetch('http://localhost:8080/student', {
        method: 'POST',
        headers: {'Content-Type' : 'application/json'},
        body: JSON.stringify({
          firstName: firstName,
          lastName: lastName,
          age: age,
          email: email,
          password: password,
          present: present
        })
      })
        if (resp.status !== 201) {
          alert('Wrong input')
      }
      const createdStudent = await resp.json();
        props.setStudents(prevStudents => [...prevStudents, createdStudent])
        props.setView('Students');
    }
    fetchStudents();
  }

  return(
    <form onSubmit = {submitHandler}>
      <h3 className="form-title">New Student</h3>
      <label>First Name</label>
      <input type="text" id="fname" name="firstname" placeholder="First name.." onChange = {e => setFirstName(e.target.value)} value={firstName}></input>
      <label>Last Name</label>
      <input type="text" id="lname" name="lastname" placeholder="Last name.." onChange = {e => setLastName(e.target.value)} value={lastName}></input>
      <label>Age</label>
      <input type="integer" id="age" name="age" placeholder="Age.." onChange = {e => setAge(e.target.value)} value={age}></input>
      <label>Email</label>
      <input type="text" id="email" name="email" placeholder="Email.." onChange = {e => setEmail(e.target.value)} value={email}></input>
      <label>Password</label>
      <input type="text" id="password" name="password" placeholder="Password.." onChange={e => setPassword(e.target.value)} value={password}></input>
      <label>Present</label>
      <input type='checkbox' id='isPresent' name='student' value='studentId' onChange={onChangehandlerPresent}></input>
      <button type= 'submit'>Save</button>
    </form>
  )
}

const UpdateStudent = (props) => {
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [age, setAge] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [present, setPresent] = useState(false)
  const onChangehandlerPresent = (e) =>{
    setPresent(prevpresent => !prevpresent)
  }
  const submitHandler = (e) => {
    e.preventDefault();
    const fetchStudents = async () => {
      const resp = await fetch(`http://localhost:8080/student/${props.viewData}`, {
        method: 'PUT',
        headers: { 'Content-type': 'application/json' },
        body: JSON.stringify({
          firstName: firstName,
          lastName: lastName,
          age: age,
          email: email,
          password: password,
          present: present
        })
      })
        if (resp.status !== 200) {
          alert('Wrong input')
        }
      const createdStudent = await resp.json();
        props.setStudents(prevStudents => [...prevStudents, createdStudent])
        props.setView('Students');
    }
    fetchStudents();
  }
  return(
    <form onSubmit = {submitHandler}>
      <h3 className="form-title">Update Student</h3>
      <label>First Name</label>
      <input type="text" id="fname" name="firstname" placeholder="First name.." onChange = {e => setFirstName(e.target.value)} value={firstName}></input>
      <label>Last Name</label>
      <input type="text" id="lname" name="lastname" placeholder="Last name.." onChange = {e => setLastName(e.target.value)} value={lastName}></input>
      <label>Age</label>
      <input type="integer" id="age" name="age" placeholder="Age.." onChange = {e => setAge(e.target.value)} value={age}></input>
      <label>Email</label>
      <input type="text" id="email" name="email" placeholder="Email.." onChange = {e => setEmail(e.target.value)} value={email}></input>
      <label>Password</label>
      <input type="text" id="password" name="password" placeholder="Password.." onChange={e => setPassword(e.target.value)} value={password}></input>
      <label>Present</label>
      <input type='checkbox' id='isPresent' name='student' value='studentId' onChange={onChangehandlerPresent}></input>
      <button type='submit' >Save</button>
    </form>
  )
}

function App() {

  const [students, setStudents] = useState([]);
  const [view, setView] = useState('');
  const [viewData, setViewData] = useState([]);

  const deleteStudent = async (students) => {
    const resp = await fetch(`http://localhost:8080/student/${students.studentId}`, {
      method: 'DELETE',
      headers: { 'Content-type': 'application/json' },
    })
    if (resp.ok) {
      setStudents(prevStudents => {
        return prevStudents.filter(prevStudents => prevStudents.studentId !== students.studentId)
      })
    }
  }

  useEffect(() => {
    const fetchStudents = async () => {
      const resp = await fetch('http://localhost:8080/student')
      const students = await resp.json()
      setStudents(students);
    }
    fetchStudents()
  }, [])

  switch (view) {
    case 'Students':
      return (
        <div className='flex-container'>
          <Students students={students} deleteStudent={deleteStudent} setView={setView} setViewData={setViewData} />
        </div>
      )
    case 'CreateStudent':
      return (
        <div className='flex-container'>
          <CreateStudent setStudents={setStudents} students={students} setView={setView} />
        </div>
      )
    case 'UpdateStudent':
      return (
        <div className='flex-container'>
          <UpdateStudent setStudents={setStudents} students={students} setView={setView} viewData={viewData} />
        </div>
      )
    default:
      return (
        <div className='flex-container'>
          <button onClick={() => { setView('CreateStudent'); }} >Create a student</button>
          <button onClick={() => { setView('Students'); }} >Student</button>
          <h1>Presence</h1>
          <Header students={students} setView={setView} />
        </div>
      );
  }
}

export default App;
